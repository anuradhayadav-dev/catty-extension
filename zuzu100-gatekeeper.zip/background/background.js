// Zuzu Gatekeeper — service worker. All session state lives in chrome.storage.local
// (timestamp based), so service-worker suspension never loses or resets the timer.
const CATS_WITH_VIDEOS = ['zuzu'];            // one cat only: ZUZU
const ROTATION = ['zuzu'];
const DEFAULTS = { minutes: 25, sites: { youtube: true, instagram: false, tiktok: false, reddit: false, x: false },
                   sound: true, animation: true, restoreMedia: false, sessionCount: 0 };

async function getSettings() { const { settings } = await chrome.storage.local.get('settings'); return { ...DEFAULTS, ...(settings || {}) }; }
async function getSession() { const { session } = await chrome.storage.local.get('session'); return session || null; }
async function setSession(s) { if (s) await chrome.storage.local.set({ session: s }); else await chrome.storage.local.remove('session'); }

function pickCats(count) {
  for (let i = 0; i < ROTATION.length; i++) {
    const slot = ROTATION[(count + i) % ROTATION.length];
    if (CATS_WITH_VIDEOS.includes(slot)) return [slot];
  }
  return ['zuzu'];
}

async function startSession(opts) {
  const old = await getSession();
  if (old && old.phase !== 'done') return { ok: false, error: 'A focus session is already running.' };
  const settings = { ...(await getSettings()), ...(opts || {}) };
  const minutes = Math.min(180, Math.max(1, Number(settings.minutes) || 25));
  const now = Date.now();
  const session = {
    id: String(now), phase: 'running',          // running | paused | ending | done
    startedAt: now, endsAt: now + minutes * 60000, durationMs: minutes * 60000, pausedRemaining: 0,
    cats: pickCats(settings.sessionCount || 0), sites: settings.sites,
    sound: !!settings.sound, animation: settings.animation !== false, restoreMedia: !!settings.restoreMedia
  };
  settings.sessionCount = (settings.sessionCount || 0) + 1;
  await chrome.storage.local.set({ settings });
  await setSession(session);
  await chrome.alarms.create('zuzu-end', { when: session.endsAt });
  return { ok: true, session };
}

async function pauseResume() {
  const s = await getSession(); if (!s) return { ok: false };
  if (s.phase === 'running') {
    s.phase = 'paused'; s.pausedRemaining = Math.max(0, s.endsAt - Date.now());
    await chrome.alarms.clear('zuzu-end');
  } else if (s.phase === 'paused') {
    s.phase = 'running'; s.endsAt = Date.now() + s.pausedRemaining;
    await chrome.alarms.create('zuzu-end', { when: s.endsAt });
  }
  await setSession(s); return { ok: true, session: s };
}

async function endSession() {
  const s = await getSession(); if (!s) return { ok: true };
  await chrome.alarms.clear('zuzu-end');
  s.phase = 'ending'; s.endsAt = Date.now(); await setSession(s);   // tabs play the exit video, then clean up
  await chrome.alarms.create('zuzu-cleanup', { when: Date.now() + 20000 });
  return { ok: true };
}

chrome.alarms.onAlarm.addListener(async (a) => {
  const s = await getSession(); if (!s) return;
  if (a.name === 'zuzu-end' && s.phase === 'running') {
    s.phase = 'ending'; await setSession(s);
    await chrome.alarms.create('zuzu-cleanup', { when: Date.now() + 20000 });
  } else if (a.name === 'zuzu-cleanup') { await setSession(null); }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg && msg.type) {
      case 'START': return startSession(msg.opts);
      case 'PAUSE_RESUME': return pauseResume();
      case 'END': return endSession();
      case 'GET': return { session: await getSession(), settings: await getSettings(), catsWithVideos: CATS_WITH_VIDEOS };
      case 'EXIT_DONE': { // a tab finished its exit animation; clear the session once it is over
        const s = await getSession();
        if (s && s.id === msg.id && s.phase === 'ending') { await chrome.alarms.clear('zuzu-cleanup'); await setSession(null); }
        return { ok: true };
      }
    }
    return { ok: false };
  })().then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e) }));
  return true;
});

// Safety net after browser restart / extension reload: expired sessions finish, live ones keep their alarm.
async function recover() {
  const s = await getSession(); if (!s) return;
  if (s.phase === 'running') {
    if (s.endsAt <= Date.now()) { s.phase = 'ending'; await setSession(s); await chrome.alarms.create('zuzu-cleanup', { when: Date.now() + 20000 }); }
    else await chrome.alarms.create('zuzu-end', { when: s.endsAt });
  } else if (s.phase === 'ending') { await chrome.alarms.create('zuzu-cleanup', { when: Date.now() + 5000 }); }
}
chrome.runtime.onStartup.addListener(recover);
chrome.runtime.onInstalled.addListener(recover);
