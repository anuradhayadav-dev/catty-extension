# Zuzu Gatekeeper 🐾 (v3.0.0) — one cat: ZUZU

Install: unzip → chrome://extensions → Developer mode ON → Load unpacked → pick the folder.
Popup: choose sites + minutes → Start Focus Mode. Open/reload the site: ZUZU leaps in from the LEFT, says hi,
lies down, grows to a huge sleeping size and sleeps until the timer ends; then wakes, stands and walks out to the RIGHT.

Assets (cut from your video): assets/videos/zuzu-entry.webm, zuzu-sleep.webm (still pose + breathing), zuzu-exit.webm.
