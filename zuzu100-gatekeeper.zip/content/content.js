// Zuzu Gatekeeper — content script. Draws the focus overlay + real cat videos over the page.
(() => {
  if (window.__zuzuLoaded) return;           // never inject twice
  window.__zuzuLoaded = true;

  const SITES = { youtube: /(^|\.)youtube\.com$/, instagram: /(^|\.)instagram\.com$/, tiktok: /(^|\.)tiktok\.com$/,
                  reddit: /(^|\.)reddit\.com$/, x: /(^|\.)(x|twitter)\.com$/ };
  const FRAME_W = 368, FRAME_H = 480;         // size of the cat video frames
  const ENTRY_SLIDE_END_S = 1.0;              // cat leaps in from the left edge to the centre in the first second
  const LIE_FROM_S = 4.9;                     // cat starts lying down here -> grows to its huge sleeping size
  const ENTRY_WALK_S = 2.7;                   // entry clip: cat is walking until here
  const ENTRY_CLIP_S = 1.1;                   // entry clip: cat is fully inside the frame from here
  const EXIT_CLIP_S = 2.55;                   // exit clip: cat starts touching the frame's right edge here
  const EXIT_WALK_FROM_S = 2.3;               // exit clip: cat stands and starts walking here
  const url = (p) => chrome.runtime.getURL(p);
  const SLEEP_ASPECT = 368 / 253;               // visible sleeping cat: width / height (frame is full width)
  const SCALE_IN_MS = 1400;
  const ease = (x) => x * x * (3 - 2 * x);
  const clamp = (v) => Math.max(0, Math.min(1, v));

  let session = null, ui = null;
  let st = { id: null, stage: 'idle', pendingExit: false, soundOff: false, raf: 0, tick: 0, sweep: 0,
             pausedByUs: new Set(), bodyInert: false, fsExited: false };

  const siteKey = () => Object.keys(SITES).find((k) => SITES[k].test(location.hostname));
  const isTarget = (s) => !!(s && s.sites && s.sites[siteKey()]);
  const fmt = (ms) => { const t = Math.max(0, Math.ceil(ms / 1000)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); };
  const remaining = (s) => (s.phase === 'paused' ? s.pausedRemaining : s.endsAt - Date.now());
  const send = (m) => { try { return chrome.runtime.sendMessage(m).catch(() => {}); } catch (e) { return Promise.resolve(); } };

  /* ---------- media pause + interaction blocking ---------- */
  function pauseAllMedia() {
    document.querySelectorAll('video,audio').forEach((m) => {
      if (m.closest('#zuzu-root')) return;
      if (!m.paused) { try { m.pause(); st.pausedByUs.add(m); } catch (e) {} }
    });
  }
  const onPlayCapture = (e) => {
    const m = e.target;
    if (!ui || !m || !m.pause || (m.closest && m.closest('#zuzu-root'))) return;
    try { m.pause(); st.pausedByUs.add(m); } catch (err) {}
  };
  const blockEvent = (e) => {
    if (ui && ui.root.contains(e.target)) return;
    e.stopImmediatePropagation(); e.preventDefault();
  };
  const BLOCKED = ['keydown', 'keyup', 'keypress', 'wheel', 'touchmove', 'contextmenu'];
  function enableBlocking() {
    BLOCKED.forEach((n) => window.addEventListener(n, blockEvent, { capture: true, passive: false }));
    document.addEventListener('play', onPlayCapture, true);
    if (document.fullscreenElement) { st.fsExited = true; document.exitFullscreen().catch(() => {}); }
    if (document.body && !document.body.inert) { document.body.inert = true; st.bodyInert = true; }
    document.documentElement.classList.add('zuzu-locked');
    pauseAllMedia(); st.sweep = setInterval(pauseAllMedia, 700);
  }
  function disableBlocking(restore) {
    BLOCKED.forEach((n) => window.removeEventListener(n, blockEvent, { capture: true }));
    document.removeEventListener('play', onPlayCapture, true);
    clearInterval(st.sweep);
    if (st.bodyInert && document.body) document.body.inert = false;
    st.bodyInert = false;
    document.documentElement.classList.remove('zuzu-locked');
    if (restore) st.pausedByUs.forEach((m) => { if (m.isConnected && m.paused) m.play().catch(() => {}); });
    st.pausedByUs.clear();
  }

  /* ---------- UI ---------- */
  function mk(tag, cls, parent, txt) { const e = document.createElement(tag); if (cls) e.className = cls; if (txt) e.textContent = txt; if (parent) parent.appendChild(e); return e; }

  function makeVideo(file, loop, parent) {
    const v = mk('video', 'zz-vid', parent);
    v.muted = true; v.loop = !!loop; v.playsInline = true; v.controls = false; v.preload = 'auto';
    v.setAttribute('disablepictureinpicture', ''); v.setAttribute('controlslist', 'nodownload nofullscreen noremoteplayback');
    v.addEventListener('error', () => showError(file));
    v.src = url('assets/videos/' + file);
    return v;
  }
  function showError(file) {
    if (!ui) return;
    ui.err.textContent = '⚠ Zuzu: cat video could not be loaded (assets/videos/' + file + '). Reinstall or re-download the extension.';
    ui.err.style.display = 'block';
    console.error('[Zuzu Gatekeeper] missing/unplayable video:', file);
  }

  function build(s) {
    teardown(false);
    const root = mk('div', '', null); root.id = 'zuzu-root';
    mk('div', 'zz-dim', root);
    const timerWrap = mk('div', 'zz-timerwrap', root);
    mk('div', 'zz-label', timerWrap, '🐾 Focus Mode');
    const timer = mk('div', 'zz-timer', timerWrap, fmt(remaining(s)));
    const status = mk('div', 'zz-status', timerWrap, '');
    const snd = mk('button', 'zz-snd', root); snd.type = 'button';
    const err = mk('div', 'zz-err', root);
    const stage = mk('div', 'zz-stage', root);
    ui = { root, timer, status, snd, err, stage, cats: [] };

    snd.addEventListener('click', () => { st.soundOff = !st.soundOff; applySound(true); });

    if (s.animation) s.cats.forEach((name, i) => {
      const el = mk('div', 'zz-cat', stage); el.dataset.cat = name;
      const entry = makeVideo(name + '-entry.webm', false, el);
      const sleep = makeVideo(name + '-sleep.webm', true, el); sleep.classList.add('zz-breath');
      const exit = makeVideo(name + '-exit.webm', false, el);
      sleep.style.opacity = 0; exit.style.opacity = 0; entry.style.opacity = 1;
      ui.cats.push({ name, el, entry, sleep, exit, idx: i, cx: 0, W: 0, done: false });
      if (i === 0) { ui.bubble = mk('div', 'zz-bubble', el, 'Hi! I’m ZUZU! 🐾'); ui.bubble.style.opacity = 0; }
    });
    document.documentElement.appendChild(root);
    applySound(false); layout(); enableBlocking();
    window.addEventListener('resize', layout);
    st.tick = setInterval(onTick, 250);
    return ui;
  }

  function applySound(userGesture) {
    if (!ui) return;
    const on = session && session.sound && !st.soundOff;
    ui.snd.textContent = on ? '🔊' : '🔇'; ui.snd.title = on ? 'Cat sounds on' : 'Cat sounds off';
    ui.cats.forEach((c) => { c.entry.muted = !on; c.exit.muted = !on; c.sleep.muted = true; });
    if (userGesture && on) ui.cats.forEach((c) => { [c.entry, c.exit].forEach((v) => { if (v.paused === false) v.muted = false; }); });
  }

  function layout() {
    if (!ui) return;
    const vw = window.innerWidth, vh = window.innerHeight, n = ui.cats.length || 1;
    // walking size: tall frame, bottom aligned (transparent top part may leave the screen)
    const H = Math.min(vh * 1.12, (vw / n) * (FRAME_H / FRAME_W));
    const W = H * (FRAME_W / FRAME_H);
    // sleeping size: as wide as the screen allows (up to full width), at most ~92% of its height
    const target = Math.min(vw / n, vh * 1.0 * SLEEP_ASPECT);
    ui.cats.forEach((c, i) => {
      c.W = W; c.gap = H * 16 / 480; c.cx = (vw * (i + 0.5)) / n; c.k = Math.max(0.5, target / W);
      c.el.style.width = W + 'px'; c.el.style.height = H + 'px'; c.el.style.left = c.cx - W / 2 + 'px';
      if (st.stage === 'sleeping') c.scale = c.k;
    });
    ui.cats.forEach(setShift);
  }

  function setShift(c) {
    const vw = window.innerWidth; let shift = 0, sc = 1;
    const left = Math.max(0, c.cx - c.W / 2);                  // frame's resting left edge on screen
    if (st.stage === 'entering') {
      // 1) the frame sits on the LEFT screen edge and the cat really walks in (all motion is the video's own legs)
      // 2) while it lies down, the frame glides to the centre and the cat grows to its big sleeping size
      const t = c.entry.currentTime, dur = c.entry.duration || 6.33;
      const q1 = ease(clamp(t / ENTRY_SLIDE_END_S));
      const q = ease(clamp((t - LIE_FROM_S) / Math.max(0.1, dur - LIE_FROM_S)));
      shift = -left * (1 - q1); sc = 1 + (c.k - 1) * q;
      if (ui.bubble) ui.bubble.style.opacity = (t > 1.2 && t < 4.8) ? 1 : 0;
    } else if (st.stage === 'sleeping') {
      sc = c.k;
    } else if (st.stage === 'exiting') {
      // 1) while it wakes and stands up it shrinks back and the frame's RIGHT edge moves to the right screen edge
      // 2) it then walks out through the right edge with its own legs
      const t = c.exit.currentTime, p = ease(clamp(t / EXIT_WALK_FROM_S));
      shift = p * Math.max(0, vw - (c.cx + c.W / 2)); sc = c.k + (1 - c.k) * p;
      if (c.exitEnd) shift += ease(clamp((performance.now() - c.exitEnd) / 700)) * c.W * 1.1;   // finish walking off-screen
      if (ui.bubble) ui.bubble.style.opacity = 0;
    }
    c.el.style.transform = 'translate3d(' + shift.toFixed(1) + 'px,' + (c.gap * sc).toFixed(1) + 'px,0) scale(' + sc.toFixed(3) + ')';
  }
  function loop() { if (!ui) return; ui.cats.forEach(setShift); st.raf = requestAnimationFrame(loop); }

  async function play(v, c) {
    try { await v.play(); }
    catch (e) {   // autoplay with sound blocked -> play silently, user can enable the 🔊 button
      v.muted = true; try { await v.play(); } catch (e2) { showError(c.name + ' (playback blocked)'); if (st.stage === 'exiting') setTimeout(finish, 3000); }
    }
  }

  /* ---------- stages ---------- */
  function startEntry() {
    st.stage = 'entering'; setStatus('Cat is arriving…');
    try { sessionStorage.setItem('zuzu-entered-' + session.id, '1'); } catch (e) {}
    if (!ui.cats.length) { st.stage = 'sleeping'; setStatus('Stay focused'); return; }
    let ended = 0;
    ui.cats.forEach((c) => {
      c.exit.load();                                            // exit clip is already preloading
      c.entry.onended = () => { if (++ended === ui.cats.length) toSleep(); };
      play(c.entry, c);
    });
    cancelAnimationFrame(st.raf); loop();
  }

  function toSleep() {
    if (!ui) return;
    st.stage = 'sleeping'; setStatus('Shh… Zuzu is sleeping 💤');
    ui.cats.forEach((c) => { c.sleep.currentTime = 0; play(c.sleep, c).then(() => { c.sleep.style.transition = c.entry.style.transition = 'none'; c.sleep.style.opacity = 1; c.entry.style.opacity = 0; setShift(c); }); });
    cancelAnimationFrame(st.raf); loop();
    if (st.pendingExit || (session && remaining(session) <= 0 && session.phase !== 'paused')) startExit();
  }

  function skipToSleep() {                                     // page reloaded mid-session: do NOT replay the walk
    st.stage = 'sleeping'; setStatus('Shh… Zuzu is sleeping 💤');
    ui.cats.forEach((c) => { c.entry.style.opacity = 0; c.sleep.style.opacity = 1; c.scale = c.k; setShift(c); play(c.sleep, c); });
  }

  function startExit() {
    if (!ui || st.stage === 'exiting' || st.stage === 'done') return;
    if (st.stage === 'entering') { st.pendingExit = true; return; }  // finish the walk-in first, then leave
    st.stage = 'exiting'; setStatus('Time’s up! Zuzu is waking up…');
    if (!ui.cats.length) return finish();
    let ended = 0;
    setTimeout(finish, 15000);                                  // watchdog: never trap the user behind the overlay
    ui.cats.forEach((c) => {
      c.exit.onerror = () => setTimeout(finish, 3000);          // diagnostic banner is shown by makeVideo's error handler
      c.exit.onended = () => { c.exitEnd = performance.now(); setTimeout(() => { c.el.style.opacity = 0; if (++ended === ui.cats.length) finish(); }, 720); };
      play(c.exit, c).then(() => { c.exit.style.opacity = 1; setTimeout(() => { c.sleep.pause(); c.sleep.style.opacity = 0; }, 180); });
    });
    cancelAnimationFrame(st.raf); loop();
  }

  function finish() {
    if (st.stage === 'done') return; st.stage = 'done';
    const id = session && session.id, restore = session && session.restoreMedia;
    teardown(restore); st.stage = 'done'; showToast(); send({ type: 'EXIT_DONE', id });
  }

  function setStatus(t) { if (ui) ui.status.textContent = t; }

  function onTick() {
    if (!ui || !session) return;
    const left = remaining(session);
    ui.timer.textContent = fmt(left);
    ui.root.classList.toggle('zz-paused', session.phase === 'paused');
    if (session.phase === 'paused' && st.stage === 'sleeping') setStatus('Paused ⏸');
    else if (session.phase === 'running' && st.stage === 'sleeping') setStatus('Shh… Zuzu is sleeping 💤');
    // timer-synchronised exit: no fixed delays, driven purely by the timestamp
    if (session.phase === 'running' && left <= 0) startExit();
    if (session.phase === 'ending') startExit();
  }

  function showToast() {
    const t = mk('div', 'zuzu-toast', null);
    mk('div', 'zuzu-toast-icon', t, '🐾'); const b = mk('div', '', t);
    mk('div', 'zuzu-toast-title', b, 'Focus Session Completed'); mk('div', 'zuzu-toast-sub', b, 'Great job! Zuzu is proud of you 💗');
    document.documentElement.appendChild(t);
    setTimeout(() => t.classList.add('zuzu-toast-out'), 4200); setTimeout(() => t.remove(), 5000);
  }

  function teardown(restore) {
    clearInterval(st.tick); cancelAnimationFrame(st.raf); window.removeEventListener('resize', layout);
    if (ui) { ui.cats.forEach((c) => [c.entry, c.sleep, c.exit].forEach((v) => { v.onended = null; try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) {} })); ui.root.remove(); }
    ui = null; if (st.stage !== 'idle') disableBlocking(restore);
    st.stage = 'idle'; st.pendingExit = false;
  }

  /* ---------- session sync ---------- */
  function apply(s) {
    session = s || null;
    if (!s || s.phase === 'done' || !isTarget(s)) { if (ui) teardown(false); st.id = null; return; }
    if (st.id === s.id && ui) { onTick(); return; }           // same session: just refresh (pause/resume/end)
    if (st.stage === 'done' && st.id === s.id) return;        // already finished this session here
    st.id = s.id;
    if (s.phase === 'ending' || (s.phase === 'running' && remaining(s) <= 0)) { send({ type: 'EXIT_DONE', id: s.id }); return; }
    build(s);
    let seen = false; try { seen = !!sessionStorage.getItem('zuzu-entered-' + s.id); } catch (e) {}
    if (!s.animation) { st.stage = 'sleeping'; setStatus('Stay focused'); }
    else if (seen) skipToSleep();
    else startEntry();
    onTick();
  }

  try {
    chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.session) apply(ch.session.newValue); });
    chrome.storage.local.get('session').then((r) => apply(r.session));
  } catch (e) { /* extension context invalidated */ }
})();
