const $ = (id) => document.getElementById(id);
const NAMES = { zuzu: 'ZUZU 🧡' };
const ROTATION = ['zuzu'];
let state = { session: null, settings: null, catsWithVideos: [] }, ticker = 0;

function fmt(ms) { const t = Math.max(0, Math.ceil(ms / 1000)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); }
const send = (m) => chrome.runtime.sendMessage(m);

function nextCats() {
  const c = state.settings.sessionCount || 0;
  for (let i = 0; i < ROTATION.length; i++) {
    const slot = ROTATION[(c + i) % ROTATION.length];
    if (state.catsWithVideos.includes(slot)) return [slot];
  }
  return ['zuzu'];
}

function render() {
  const { session, settings } = state, live = session && session.phase !== 'done';
  const cats = live ? session.cats : nextCats();
  $('catImg').src = '../assets/img/' + cats[0] + '.png';
  $('catName').textContent = cats.length > 1 ? cats.map((c) => NAMES[c].split(' ')[0]).join(' + ') + ' 🐾' : NAMES[cats[0]];
  $('catNote').textContent = live ? 'On duty this session' : 'Your focus buddy';
  $('setup').style.opacity = live ? .55 : 1;
  document.querySelectorAll('#setup input, #presets button').forEach((e) => (e.disabled = !!live));
  $('start').hidden = !!live; $('pause').hidden = !live; $('end').hidden = !live;
  if (live) {
    $('pause').textContent = session.phase === 'paused' ? '▶ Resume' : '⏸ Pause';
    $('status').textContent = session.phase === 'paused' ? 'Paused' : session.phase === 'ending' ? 'Zuzu is leaving…' : 'Focus in progress — Zuzu is sleeping 💤';
  } else $('status').textContent = 'Ready when you are';
  tick();
}
function tick() {
  const s = state.session;
  if (s && s.phase !== 'done') $('clock').textContent = fmt(s.phase === 'paused' ? s.pausedRemaining : s.phase === 'ending' ? 0 : s.endsAt - Date.now());
  else $('clock').textContent = fmt((Number($('minutes').value) || 25) * 60000);
}

async function load() {
  state = await send({ type: 'GET' });
  const st = state.settings;
  $('minutes').value = st.minutes; $('sound').checked = st.sound; $('animation').checked = st.animation; $('restore').checked = st.restoreMedia;
  document.querySelectorAll('[data-site]').forEach((e) => (e.checked = !!st.sites[e.dataset.site]));
  render();
}
async function saveSettings() {
  const sites = {}; document.querySelectorAll('[data-site]').forEach((e) => (sites[e.dataset.site] = e.checked));
  const s = { ...state.settings, minutes: Math.min(180, Math.max(1, Number($('minutes').value) || 25)), sites,
              sound: $('sound').checked, animation: $('animation').checked, restoreMedia: $('restore').checked };
  state.settings = s; await chrome.storage.local.set({ settings: s });
}
document.querySelectorAll('#setup input').forEach((e) => e.addEventListener('change', async () => { await saveSettings(); tick(); }));
document.querySelectorAll('#presets button').forEach((b) => b.addEventListener('click', async () => { $('minutes').value = b.dataset.m; await saveSettings(); tick(); }));

$('start').addEventListener('click', async () => {
  await saveSettings();
  if (!Object.values(state.settings.sites).some(Boolean)) { $('msg').textContent = 'Pick at least one website first.'; return; }
  const r = await send({ type: 'START' });
  if (!r.ok) { $('msg').textContent = r.error || 'Could not start.'; return; }
  const tabs = await chrome.tabs.query({ url: ['*://*.youtube.com/*', '*://*.instagram.com/*', '*://*.tiktok.com/*', '*://*.reddit.com/*', '*://x.com/*', '*://*.x.com/*', '*://twitter.com/*', '*://*.twitter.com/*'] });
  const active = Object.keys(state.settings.sites).filter((k) => state.settings.sites[k]);
  $('msg').textContent = tabs.length ? 'Focus started 🐾 (' + active.join(', ') + ')' : 'Started — open ' + active.join(' / ') + ' and the cat will arrive. 🐾';
  await load();
});
$('pause').addEventListener('click', async () => { await send({ type: 'PAUSE_RESUME' }); await load(); });
$('end').addEventListener('click', async () => { await send({ type: 'END' }); $('msg').textContent = 'Ending — Zuzu is leaving.'; await load(); });

chrome.storage.onChanged.addListener(() => load());
ticker = setInterval(tick, 500);
load();
